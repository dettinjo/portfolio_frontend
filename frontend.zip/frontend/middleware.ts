import { NextRequest, NextResponse } from 'next/server';
import { routing } from './src/i18n/routing'; // Import our config
import createMiddleware from 'next-intl/middleware';

// This is a custom function to determine the locale
function getLocale(request: NextRequest): string {
  // 1. Check for a language cookie if you have one (optional)
  // const locale = request.cookies.get('NEXT_LOCALE')?.value;

  // 2. Read the "Accept-Language" header
  const acceptLanguage = request.headers.get('accept-language');
  if (acceptLanguage) {
    // A simple parser to get the primary language (e.g., 'de' from 'de-DE,de;q=0.9,en-US;...')
    const primaryLanguage = acceptLanguage.split(',')[0].split('-')[0];
    if (routing.locales.includes(primaryLanguage as any)) {
      return primaryLanguage;
    }
  }
  
  // 3. Fallback to the default locale
  return routing.defaultLocale;
}

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  console.log('\n--- MIDDLEWARE DIAGNOSTICS ---');
  console.log('Request Pathname:', pathname);
  
  // Log the configuration we are using
  console.log('Imported Routing Config:', JSON.stringify(routing, null, 2));

  // Skip middleware for API, Next.js internal files, and files with extensions
  const pathnameHasExtension = /\..*$/.test(pathname);
  if (
    pathname.startsWith('/api/') ||
    pathname.startsWith('/_next') ||
    pathnameHasExtension
  ) {
    console.log('Skipping middleware for this path.');
    console.log('--- END DIAGNOSTICS ---\n');
    return NextResponse.next();
  }

  // --- MANUAL REDIRECT LOGIC ---
  // Check if the pathname is missing a locale prefix
  const pathnameIsMissingLocale = routing.locales.every(
    (locale) => !pathname.startsWith(`/${locale}/`) && pathname !== `/${locale}`
  );

  if (pathnameIsMissingLocale) {
    const locale = getLocale(request);
    const newUrl = new URL(`/${locale}${pathname}`, request.url);
    
    console.log('Path is missing locale. Detected locale:', locale);
    console.log('MANUALLY REDIRECTING to:', newUrl.toString());
    console.log('--- END DIAGNOSTICS ---\n');
    
    return NextResponse.redirect(newUrl);
  }

  console.log('Path already has a locale. Passing to next-intl handler.');
  console.log('--- END DIAGNOSTICS ---\n');
  
  // If a locale is already present, let the original handler do its work.
  const handleNextIntl = createMiddleware(routing);
  return handleNextIntl(request);
}

export const config = {
  // We need to match everything to let our custom logic run
  matcher: '/((?!api|_next/static|_next/image|favicon.ico).*)'
};