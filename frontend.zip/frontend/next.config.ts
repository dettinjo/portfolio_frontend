import { NextConfig } from 'next';
import createNextIntlPlugin from 'next-intl/plugin';
 
// This line creates the plugin instance.
// The path to your i18n configuration file is passed here.
const withNextIntl = createNextIntlPlugin('./src/i18n/request.ts');
 
/** @type {import('next').NextConfig} */
const nextConfig: NextConfig = {
  // Your regular Next.js config options go here
};
 
// The plugin wraps your Next.js config.
export default withNextIntl(nextConfig);