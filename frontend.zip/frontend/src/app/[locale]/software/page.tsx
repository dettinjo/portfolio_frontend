// src/appsections/software/page.tsx

// Importieren Sie Ihre neuen Sektions-Komponenten
import { ContactSection } from "@/components/sections/software/ContactSection";
import { HeroSection } from "@/components/sections/software/HeroSection";
import { ProjectsSection } from "@/components/sections/software/ProjectsSection";
import { SkillsSection } from "@/components/sections/software/SkillsSection";

// --- Beispieldaten (später von API) ---
const projectsData = [
  {
    id: 1,
    slug: "projekt-eins",
    title: "Portfolio Webseite",
    description: "Eine Webseite zur Präsentation meiner Projekte...",
    tags: ["Next.js", "React", "Strapi"],
  },
  {
    id: 2,
    slug: "projekt-zwei",
    title: "Mobile App für Notizen",
    description: "Eine plattformübergreifende Notizen-App...",
    tags: ["React Native", "Firebase"],
  },
  {
    id: 3,
    slug: "projekt-drei",
    title: "E-Commerce Backend",
    description: "Eine robuste REST-API für einen Online-Shop...",
    tags: ["Node.js", "MongoDB"],
  },
];
const skillsData = [
  "TypeScript",
  "React",
  "Next.js",
  "Node.js",
  "Python",
  "Docker",
  "PostgreSQL",
  "System Design",
  "Agile Methoden",
];

export default function DevPage() {
  return (
    <div className="space-y-24">
      <HeroSection />
      <ProjectsSection projects={projectsData} />
      <SkillsSection skills={skillsData} />
      <ContactSection />
    </div>
  );
}
