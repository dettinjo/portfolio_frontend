import { Terminal, Camera } from "lucide-react";
import { MinimalHeader } from "@/components/layout/MinimalHeader";

export default function HomePage() {
  return (
    <>
      <MinimalHeader />
      <div className="container mx-auto flex min-h-screen items-center justify-center">
        <div className="grid w-full max-w-4xl grid-cols-1 gap-12 md:grid-cols-2">
          <a
            href="/software"
            className="group flex flex-col items-center justify-center ..."
          >
            <Terminal className="h-28 w-28 ..." />
            <span className="text-3xl font-semibold ...">Code</span>
          </a>

          <a
            href="/photography"
            className="group flex flex-col items-center justify-center ..."
          >
            <Camera className="h-28 w-28 ..." />
            <span className="text-3xl font-semibold ...">Photos</span>
          </a>
        </div>
      </div>
    </>
  );
}
