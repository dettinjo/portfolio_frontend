"use client"; // This must be a client component to use hooks

import { useTranslations } from "next-intl";
import { ThemeToggle } from "./ThemeToggle";
import { LanguageToggle } from "./LanguageToggle";

export function PhotographyHeader() {
  // Initialize the translation hook with the correct namespace from your JSON files
  const t = useTranslations("PhotographyHeader");

  return (
    // The "border-b" class has been removed for a seamless look
    <header className="sticky top-0 z-50 w-full bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <nav className="container mx-auto flex h-14 items-center justify-between">
        {/* Column 1: Logo (Left) */}
        <a href="/photography" className="font-bold">
          [Your Name] / Photography
        </a>

        {/* Column 2: Navigation Links (Center) */}
        <div className="flex items-center gap-6 text-sm">
          {/* Menu items are now dynamically translated */}
          <a
            href="#galerien"
            className="text-muted-foreground transition-colors hover:text-foreground"
          >
            {t("galleries")}
          </a>
          <a
            href="#services"
            className="text-muted-foreground transition-colors hover:text-foreground"
          >
            {t("services")}
          </a>
          <a
            href="#kontakt"
            className="text-muted-foreground transition-colors hover:text-foreground"
          >
            {t("contact")}
          </a>
        </div>

        {/* Column 3: Toggles (Right) */}
        <div className="flex items-center gap-2">
          <LanguageToggle />
          <ThemeToggle />
        </div>
      </nav>
    </header>
  );
}
