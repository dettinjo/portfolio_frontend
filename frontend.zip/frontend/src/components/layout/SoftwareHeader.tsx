"use client"; // This must be a client component to use hooks

import { useTranslations } from "next-intl";
import { ThemeToggle } from "./ThemeToggle";
import { LanguageToggle } from "./LanguageToggle";

export function SoftwareHeader() {
  // Initialize the translation hook with the correct namespace from your JSON files
  const t = useTranslations("SoftwareHeader");

  return (
    // The "border-b" class has been removed for a seamless look
    <header className="sticky top-0 z-50 w-full bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <nav className="container mx-auto flex h-14 items-center justify-between">
        {/* Column 1: Logo (Left) */}
        <a href="/dev" className="font-bold">
          [Your Name] / Software
        </a>

        {/* Column 2: Navigation Links (Center) */}
        <div className="flex items-center gap-6 text-sm">
          {/* Menu items are now dynamically translated */}
          <a
            href="#projekte"
            className="text-muted-foreground transition-colors hover:text-foreground"
          >
            {t("projects")}
          </a>
          <a
            href="#skills"
            className="text-muted-foreground transition-colors hover:text-foreground"
          >
            {t("skills")}
          </a>
          <a
            href="#kontakt"
            className="text-muted-foreground transition-colors hover:text-foreground"
          >
            {t("contact")}
          </a>
        </div>

        {/* Column 3: Toggles (Right) */}
        <div className="flex items-center gap-2">
          <LanguageToggle />
          <ThemeToggle />
        </div>
      </nav>
    </header>
  );
}
