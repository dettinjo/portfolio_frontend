// src/components/layout/LanguageToggle.tsx
"use client";

import { useLocale } from "next-intl";
import { useRouter } from "next/navigation";
import { usePathname } from "next/navigation";
import { Button } from "../ui/button";

export function LanguageToggle() {
  const router = useRouter();
  const pathname = usePathname();
  const locale = useLocale();

  const changeLanguage = (nextLocale: "en" | "de") => {
    // Ersetzt das /de oder /en am Anfang des Pfades
    const newPath = pathname.replace(`/${locale}`, `/${nextLocale}`);
    router.replace(newPath);
  };

  return (
    <div className="flex items-center border-2 border-foreground rounded-md">
      <Button
        variant={locale === "de" ? "default" : "ghost"}
        size="sm"
        className="rounded-r-none"
        onClick={() => changeLanguage("de")}
      >
        DE
      </Button>
      <Button
        variant={locale === "en" ? "default" : "ghost"}
        size="sm"
        className="rounded-l-none"
        onClick={() => changeLanguage("en")}
      >
        EN
      </Button>
    </div>
  );
}
