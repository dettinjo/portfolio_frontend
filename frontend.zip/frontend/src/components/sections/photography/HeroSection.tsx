export function HeroSection() {
  return (
    <section
      id="hero"
      className="relative h-[60vh] flex items-center justify-center text-center text-white -mt-8 -mx-8"
    >
      <div className="absolute inset-0 bg-black/50 z-10" />
      <img
        src="https://placehold.co/1200x800/000000/FFFFFF/png?text=Ihr+bestes+Foto"
        alt="Hero Image"
        className="absolute inset-0 w-full h-full object-cover"
      />
      <div className="z-20">
        <h1 className="text-4xl font-bold tracking-tight lg:text-6xl drop-shadow-md">
          Momente einfangen. Geschichten erzählen.
        </h1>
        <p className="mt-6 max-w-3xl mx-auto text-lg drop-shadow">
          Authentische und ästhetische Fotografie, die Emotionen und
          Persönlichkeiten sichtbar macht.
        </p>
      </div>
    </section>
  );
}
