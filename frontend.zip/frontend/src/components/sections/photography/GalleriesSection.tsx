import { AnimatedGrid, AnimatedGridItem } from "@/components/AnimatedGrid";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

// --- Beispieldaten (später von API) ---
const albums = [
  {
    id: 1,
    slug: "portraits-sw",
    title: "Portraits in S/W",
    description: "Kontrastreiche Charakterstudien.",
    coverImageUrl:
      "https://placehold.co/600x400/000000/FFFFFF/png?text=Portrait",
  },
  {
    id: 2,
    slug: "architektur-berlin",
    title: "Architektur in Berlin",
    description: "Linien, Formen und Strukturen.",
    coverImageUrl:
      "https://placehold.co/600x400/000000/FFFFFF/png?text=Architektur",
  },
  {
    id: 3,
    slug: "natur-alpen",
    title: "Natur in den Alpen",
    description: "Majestätische Berglandschaften.",
    coverImageUrl: "https://placehold.co/600x400/000000/FFFFFF/png?text=Natur",
  },
];

export function GalleriesSection() {
  return (
    <section id="galerien">
      <div className="mb-12 text-center">
        <h2 className="text-3xl font-bold">Galerien</h2>
        <p className="mt-2 text-muted-foreground">
          Entdecken Sie eine Auswahl meiner Arbeiten.
        </p>
      </div>
      <AnimatedGrid>
        {albums.map((album) => (
          <AnimatedGridItem key={album.id}>
            <a
              href={`/photography/${album.slug}`}
              className="block group h-full"
            >
              <Card className="overflow-hidden h-full">
                <CardContent className="p-0">
                  <AspectRatio ratio={4 / 3}>
                    <img
                      src={album.coverImageUrl}
                      alt={album.title}
                      className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                  </AspectRatio>
                </CardContent>
                <CardHeader>
                  <CardTitle>{album.title}</CardTitle>
                  <CardDescription>{album.description}</CardDescription>
                </CardHeader>
              </Card>
            </a>
          </AnimatedGridItem>
        ))}
      </AnimatedGrid>
    </section>
  );
}
