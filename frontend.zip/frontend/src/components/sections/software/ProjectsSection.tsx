"use client"; // Notwendig wegen Framer Motion (AnimatedGrid)
import { AnimatedGrid, AnimatedGridItem } from "@/components/AnimatedGrid";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

// Wir definieren, welche Daten (Props) diese Komponente erwartet
interface Project {
  id: number;
  slug: string;
  title: string;
  description: string;
  tags: string[];
}
interface ProjectsSectionProps {
  projects: Project[];
}

export function ProjectsSection({ projects }: ProjectsSectionProps) {
  return (
    <section id="projekte">
      <div className="mb-12 text-center">
        <h2 className="text-3xl font-bold">Ausgewählte Projekte</h2>
        <p className="mt-2 text-muted-foreground">
          Ein Einblick in meine Problemlösungsfähigkeiten.
        </p>
      </div>
      <AnimatedGrid>
        {projects.map((project) => (
          <AnimatedGridItem key={project.id}>
            <Card className="flex flex-col h-full">
              <CardHeader>
                <CardTitle>{project.title}</CardTitle>
                <CardDescription>{project.description}</CardDescription>
              </CardHeader>
              <CardContent className="flex-grow">
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag) => (
                    <Badge key={tag} variant="secondary">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <a href={`/dev/${project.slug}`}>Details ansehen</a>
                </Button>
              </CardFooter>
            </Card>
          </AnimatedGridItem>
        ))}
      </AnimatedGrid>
    </section>
  );
}
