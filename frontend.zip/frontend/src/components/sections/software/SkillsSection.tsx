import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";

interface SkillsSectionProps {
  skills: string[];
}

export function SkillsSection({ skills }: SkillsSectionProps) {
  return (
    <section id="skills">
      <div className="mb-12 text-center">
        <h2 className="text-3xl font-bold">Technologien & Skills</h2>
        <p className="mt-2 text-muted-foreground">
          Mein Werkzeugkasten für moderne Softwareentwicklung.
        </p>
      </div>
      <Card>
        <CardContent className="p-6 flex flex-wrap justify-center gap-4">
          {skills.map((skill) => (
            <Badge key={skill} className="text-lg py-1 px-4">
              {skill}
            </Badge>
          ))}
        </CardContent>
      </Card>
    </section>
  );
}
