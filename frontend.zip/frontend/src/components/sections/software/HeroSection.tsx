import { Button } from "@/components/ui/button";

export function HeroSection() {
  return (
    <section id="hero" className="text-center pt-16">
      <h1 className="text-4xl font-bold tracking-tight lg:text-6xl">
        Digitale Lösungen, durchdacht und umgesetzt.
      </h1>
      <p className="mt-6 max-w-3xl mx-auto text-lg text-muted-foreground">
        Ich bin ein Full-Stack Entwickler, der robuste, skalierbare und
        benutzerfreundliche Webanwendungen konzipiert und realisiert.
      </p>
      <div className="mt-8 flex justify-center gap-4">
        <Button asChild>
          <a href="#projekte">Meine Arbeit ansehen</a>
        </Button>
        <Button asChild variant="secondary">
          <a href="#kontakt">Kontakt aufnehmen</a>
        </Button>
      </div>
    </section>
  );
}
